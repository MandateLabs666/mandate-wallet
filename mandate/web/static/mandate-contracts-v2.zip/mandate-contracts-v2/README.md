# Mandate Wallet v2 contracts

MIT-licensed source, tests, exact dependency import closure, ABIs and historical testnet deployment inputs.
Third-party code retains its own license notices under contracts/lib/.

## Reproduce locally

Requirements: Foundry 1.5.1 and Solidity 0.8.26. The original paths and foundry.toml are retained.

```sh
forge build --root mandate/contracts
forge test --root mandate/contracts
```

MandateAccount and MandateFactory are the protocol contracts. TestUSDC and MockUSDC are test-only mintable assets.
No deployment command is run automatically. The package includes no owner/session key, Gateway credential, environment file or private project material.
Mainnet payments are not enabled. Check deployments.json and verification-inputs/ for the historical public testnet identity.
The download is source publication, not an audit, a guarantee of safety, an explorer verification badge or proof of current funding/session availability.

## Core behavior

The owner creates a finite policy and then grants an explicit session. The session registers a payment commitment before an EIP-3009 signature can be accepted by ERC-1271. Paid or unresolved commitments occupy budget. An expired unused nonce can be released; a paid nonce cannot. Replacing or pausing a policy changes its version, making previous grants stale. Revocation is irreversible.
Payment, service delivery and result checks are separate. The contract enforces the financial scope and request/quote hashes, not the entire off-chain session evidence root.
